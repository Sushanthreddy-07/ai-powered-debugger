import * as vscode from "vscode";
// @ts-ignore – using CJS build of node-fetch for extension host
import fetch from "node-fetch";

function getBackendBaseUrl(): string {
  const cfg = vscode.workspace.getConfiguration("aibugfixer");
  return cfg.get<string>("backendBaseUrl", "http://localhost:8000");
}

export function activate(context: vscode.ExtensionContext) {
  const fixCmd = vscode.commands.registerCommand("aibugfixer.fixCode", async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) {
      vscode.window.showErrorMessage("AIbugfixer: No active editor.");
      return;
    }

    const selection = editor.selection;
    const hasSelection = !selection.isEmpty;

    const range = hasSelection
      ? selection
      : new vscode.Range(
          editor.document.positionAt(0),
          editor.document.positionAt(editor.document.getText().length)
        );

    const code = editor.document.getText(range);
    if (!code.trim()) {
      vscode.window.showWarningMessage("AIbugfixer: No code to fix.");
      return;
    }

    const baseUrl = getBackendBaseUrl();
    const url = `${baseUrl.replace(/\/+$/, "")}/fix`;

    await vscode.window.withProgress(
      { location: vscode.ProgressLocation.Notification, title: "AIbugfixer: Fixing code…", cancellable: false },
      async () => {
        try {
          const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code, error_message: "" })
          });

          if (!res.ok) {
            const bodyText = await res.text();
            throw new Error(`HTTP ${res.status} ${res.statusText} – ${bodyText}`);
          }

          const data = (await res.json()) as { fixed_code?: string };
          if (!data.fixed_code || !data.fixed_code.trim()) {
            vscode.window.showWarningMessage("AIbugfixer: No fix returned from backend.");
            return;
          }

          await editor.edit((eb) => eb.replace(range, data.fixed_code!));
          vscode.window.showInformationMessage("✅ AIbugfixer: Code fixed.");
        } catch (err: any) {
          vscode.window.showErrorMessage(`AIbugfixer error: ${err.message || String(err)}`);
        }
      }
    );
  });

  context.subscriptions.push(fixCmd);
}

export function deactivate() {}
